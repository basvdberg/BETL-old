﻿CREATE SCHEMA [static]
    AUTHORIZATION [SVB\AVBVDBE1];


GO
EXECUTE sp_addextendedproperty @name = N'Description', @value = N'Static betl data, not dependent on customer implementation', @level0type = N'SCHEMA', @level0name = N'static';

