﻿CREATE SCHEMA [ddp_idv]
    AUTHORIZATION [dbo];

