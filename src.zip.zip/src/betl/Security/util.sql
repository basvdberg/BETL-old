﻿CREATE SCHEMA [util]
    AUTHORIZATION [SVB\AVBVDBE1];


GO
EXECUTE sp_addextendedproperty @name = N'Description', @value = N'Generic utility data and functions', @level0type = N'SCHEMA', @level0name = N'util';

