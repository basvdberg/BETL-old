﻿CREATE TYPE [dbo].[SplitList] AS TABLE (
    [item] VARCHAR (MAX) NULL,
    [i]    INT           NULL);

