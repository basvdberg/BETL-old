﻿CREATE TABLE [dbo].[Col_hist] (
    [column_id]            INT           IDENTITY (1, 1) NOT NULL,
    [eff_dt]               DATETIME      NOT NULL,
    [obj_id]               INT           NOT NULL,
    [column_name]          VARCHAR (64)  NOT NULL,
    [prefix]               VARCHAR (64)  NULL,
    [entity_name]          VARCHAR (64)  NULL,
    [foreign_column_id]    INT           NULL,
    [ordinal_position]     SMALLINT      NULL,
    [is_nullable]          BIT           NULL,
    [data_type]            VARCHAR (100) NULL,
    [max_len]              INT           NULL,
    [numeric_precision]    INT           NULL,
    [numeric_scale]        INT           NULL,
    [column_type_id]       INT           NULL,
    [src_column_id]        INT           NULL,
    [delete_dt]            DATETIME      NULL,
    [record_dt]            DATETIME      DEFAULT (getdate()) NULL,
    [record_user]          VARCHAR (50)  DEFAULT (suser_sname()) NULL,
    [chksum]               INT           NOT NULL,
    [transfer_id]          INT           NULL,
    [part_of_unique_index] BIT           DEFAULT ((0)) NULL,
    CONSTRAINT [PK__Hst_column] PRIMARY KEY CLUSTERED ([column_id] ASC, [eff_dt] DESC),
    CONSTRAINT [FK_Col_hist_Column_type] FOREIGN KEY ([column_type_id]) REFERENCES [static].[Column_type] ([column_type_id]),
    CONSTRAINT [FK_Col_hist_Obj] FOREIGN KEY ([obj_id]) REFERENCES [dbo].[Obj] ([obj_id])
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Unique__Column_obj_col_eff]
    ON [dbo].[Col_hist]([obj_id] ASC, [column_name] ASC, [eff_dt] ASC);

