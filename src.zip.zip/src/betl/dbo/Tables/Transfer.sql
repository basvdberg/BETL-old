﻿CREATE TABLE [dbo].[Transfer] (
    [transfer_id]       INT           IDENTITY (1, 1) NOT NULL,
    [batch_id]          INT           NULL,
    [transfer_name]     VARCHAR (100) NULL,
    [src_obj_id]        INT           NULL,
    [target_name]       VARCHAR (255) NULL,
    [transfer_start_dt] DATETIME      NULL,
    [transfer_end_dt]   DATETIME      NULL,
    [status_id]         INT           NULL,
    [rec_cnt_src]       INT           NULL,
    [rec_cnt_new]       INT           NULL,
    [rec_cnt_changed]   INT           NULL,
    [rec_cnt_deleted]   INT           NULL,
    [last_error_id]     INT           NULL,
    [prev_transfer_id]  INT           NULL,
    [transfer_seq]      INT           NULL,
    CONSTRAINT [PK_transfer_id] PRIMARY KEY CLUSTERED ([transfer_id] DESC),
    CONSTRAINT [FK_Transfer_Batch] FOREIGN KEY ([batch_id]) REFERENCES [dbo].[Batch] ([batch_id]),
    CONSTRAINT [FK_Transfer_Error] FOREIGN KEY ([last_error_id]) REFERENCES [dbo].[Error] ([error_id]),
    CONSTRAINT [FK_Transfer_Obj] FOREIGN KEY ([src_obj_id]) REFERENCES [dbo].[Obj] ([obj_id]),
    CONSTRAINT [FK_Transfer_Status] FOREIGN KEY ([status_id]) REFERENCES [static].[Status] ([status_id]),
    CONSTRAINT [FK_Transfer_Transfer] FOREIGN KEY ([prev_transfer_id]) REFERENCES [dbo].[Transfer] ([transfer_id])
);


GO
CREATE NONCLUSTERED INDEX [ix_transfer_transfer_name_seq_nr]
    ON [dbo].[Transfer]([transfer_name] ASC, [transfer_seq] ASC);


GO
CREATE UNIQUE NONCLUSTERED INDEX [ix_Transfer_batch_transfer_name_unique]
    ON [dbo].[Transfer]([batch_id] ASC, [transfer_name] ASC);

