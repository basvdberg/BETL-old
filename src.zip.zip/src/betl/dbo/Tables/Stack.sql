﻿CREATE TABLE [dbo].[Stack] (
    [stack_id]    INT            IDENTITY (1, 1) NOT NULL,
    [value]       VARCHAR (4000) NULL,
    [record_dt]   DATETIME       DEFAULT (getdate()) NULL,
    [record_user] VARCHAR (255)  DEFAULT (suser_sname()) NULL,
    CONSTRAINT [PK_Stack] PRIMARY KEY CLUSTERED ([stack_id] DESC)
);

