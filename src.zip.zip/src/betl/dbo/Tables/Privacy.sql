﻿CREATE TABLE [dbo].[Privacy] (
    [db]          VARCHAR (50)   NULL,
    [table_name]  NVARCHAR (255) NULL,
    [sensitive]   NVARCHAR (255) NULL,
    [column_name] NVARCHAR (255) NULL,
    [personal]    NVARCHAR (255) NULL
);

