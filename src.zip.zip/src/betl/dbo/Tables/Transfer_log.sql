﻿CREATE TABLE [dbo].[Transfer_log] (
    [log_id]       INT           IDENTITY (1, 1) NOT NULL,
    [log_dt]       DATETIME      CONSTRAINT [DF__Transfer___log_d__3D5E1FD2] DEFAULT (getdate()) NULL,
    [msg]          VARCHAR (MAX) NULL,
    [transfer_id]  INT           NULL,
    [log_level_id] SMALLINT      NULL,
    [log_type_id]  SMALLINT      NULL,
    [exec_sql]     BIT           NULL,
    CONSTRAINT [PK_log_id] PRIMARY KEY CLUSTERED ([log_id] DESC),
    CONSTRAINT [FK_Transfer_log_Log_level] FOREIGN KEY ([log_level_id]) REFERENCES [static].[Log_level] ([log_level_id]),
    CONSTRAINT [FK_Transfer_log_Log_type] FOREIGN KEY ([log_type_id]) REFERENCES [static].[Log_type] ([log_type_id]),
    CONSTRAINT [FK_Transfer_log_Transfer] FOREIGN KEY ([transfer_id]) REFERENCES [dbo].[Transfer] ([transfer_id])
);

