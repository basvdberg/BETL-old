﻿CREATE TABLE [dbo].[Obj] (
    [obj_id]             INT            IDENTITY (1, 1) NOT NULL,
    [obj_type_id]        INT            NOT NULL,
    [server_type_id]     INT            CONSTRAINT [DF__Obj__server_type__6383C8BA] DEFAULT ((10)) NULL,
    [obj_name]           NVARCHAR (128) NOT NULL,
    [parent_id]          INT            NULL,
    [scope]              NVARCHAR (50)  NULL,
    [identifier]         INT            NULL,
    [template_id]        SMALLINT       NULL,
    [delete_dt]          DATETIME       NULL,
    [record_dt]          DATETIME       CONSTRAINT [DF__Obj__record_dt__6477ECF3] DEFAULT (getdate()) NULL,
    [record_user]        NVARCHAR (50)  CONSTRAINT [DF__Obj__record_user__656C112C] DEFAULT (suser_sname()) NULL,
    [prefix]             NVARCHAR (50)  NULL,
    [obj_name_no_prefix] NVARCHAR (128) NULL,
    CONSTRAINT [PK__Obj] PRIMARY KEY CLUSTERED ([obj_id] DESC),
    CONSTRAINT [FK__obj__obj] FOREIGN KEY ([parent_id]) REFERENCES [dbo].[Obj] ([obj_id]),
    CONSTRAINT [FK_Obj_Obj_type] FOREIGN KEY ([obj_type_id]) REFERENCES [static].[Obj_type] ([obj_type_id]),
    CONSTRAINT [FK_Obj_Server_type] FOREIGN KEY ([server_type_id]) REFERENCES [static].[Server_type] ([server_type_id]),
    CONSTRAINT [FK_Obj_Template] FOREIGN KEY ([template_id]) REFERENCES [static].[Template] ([template_id])
);

