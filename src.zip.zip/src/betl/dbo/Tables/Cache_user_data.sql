﻿CREATE TABLE [dbo].[Cache_user_data] (
    [user_name]     NVARCHAR (128) NOT NULL,
    [log_level]     NVARCHAR (128) NULL,
    [exec_sql]      BIT            NULL,
    [record_dt]     DATETIME       CONSTRAINT [DF_Cache_user_data_record_dt] DEFAULT (getdate()) NULL,
    [expiration_dt] DATETIME       NULL,
    CONSTRAINT [PK_Cache_1] PRIMARY KEY CLUSTERED ([user_name] ASC)
);

