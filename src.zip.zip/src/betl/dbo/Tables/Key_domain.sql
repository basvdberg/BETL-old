﻿CREATE TABLE [dbo].[Key_domain] (
    [key_domain_name] VARCHAR (255) NOT NULL,
    [key_domain_id]   INT           NOT NULL,
    CONSTRAINT [PK_Key_domain] PRIMARY KEY CLUSTERED ([key_domain_name] ASC)
);

