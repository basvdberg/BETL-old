﻿CREATE TABLE [dbo].[Batch] (
    [batch_id]       INT           IDENTITY (1, 1) NOT NULL,
    [batch_name]     VARCHAR (100) NULL,
    [batch_start_dt] DATETIME      DEFAULT (getdate()) NULL,
    [batch_end_dt]   DATETIME      NULL,
    [status_id]      INT           NULL,
    [last_error_id]  INT           NULL,
    [prev_batch_id]  INT           NULL,
    [exec_server]    VARCHAR (100) DEFAULT (@@servername) NULL,
    [exec_host]      VARCHAR (100) DEFAULT (host_name()) NULL,
    [exec_user]      VARCHAR (100) DEFAULT (suser_sname()) NULL,
    [guid]           BIGINT        NULL,
    [continue_batch] BIT           DEFAULT ((0)) NULL,
    [batch_seq]      INT           NULL,
    CONSTRAINT [PK_run_id] PRIMARY KEY CLUSTERED ([batch_id] DESC),
    CONSTRAINT [FK_Batch_Batch] FOREIGN KEY ([prev_batch_id]) REFERENCES [dbo].[Batch] ([batch_id]),
    CONSTRAINT [FK_Batch_Error] FOREIGN KEY ([last_error_id]) REFERENCES [dbo].[Error] ([error_id])
);

