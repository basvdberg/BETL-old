﻿	  
/*------------------------------------------------------------------------------------------------
-- BETL, meta data driven ETL generation, licensed under GNU GPL https://github.com/basvdberg/BETL 
--------------------------------------------------------------------------------------------------
-- 2012-03-04 BvdB push implements the core of BETL. 
-- In it's most simple form it will copy a table from A (source) to B (target). If target does not exist
-- it will be created. It can also do natural foreign key lookups, create and refresh lookup tables, add meta data. etc. 
-- all based on the template_id. 
-- betl will try to find the src object. If its name is ambiguous, it will trhow an error
logging hierarchy
-----------------
batch_id -> transfer_id -> transfer_log_id 
You can choose to let BETL generate the logging hierarchy, or you can integrate 
external logging hierachy. In this case you should supply the batch_id. 
The logging hierarchy is used in betl ssrs run log. 
exec betl.dbo.setp 'log_level', 'debug'
exec betl.dbo.push 'AdventureWorks2014.Production.Product'
exec betl.dbo.info 'AdventureWorks2014'
exec betl.dbo.setp 'recreate_tables', 1 , 'My_Staging'
exec betl.dbo.setp 'log_level', verbose
exec betl.[dbo].[my_info]
exec betl.[dbo].[info] '[AdventureWorks2014].[idv].[stgh_relatie]'
exec betl.dbo.push '[AdventureWorks2014].[idv].[stgh_relatie]'
*/
CREATE PROCEDURE [dbo].[push]
    @full_obj_name as nvarchar(255)
	, @batch_id as int = 0 -- see logging hierarchy above.
	, @template_id as smallint=null
	, @scope as varchar(255) = null 
	, @transfer_id as int = 0 -- see logging hierarchy above.
	, @async as bit=0 -- run asynchronously 
AS
BEGIN
	begin try 
--declare
--    @full_obj_name as varchar(255) = '[AdventureWorks2014].[idv].[stgl_relatieboom]'
--	, @batch_id as int = -1
--	, @scope as varchar(255) = null 
--	, @transfer_id as int = -1 -- see logging hierarchy above.
   set nocount on 
	declare @proc_name as varchar(255) =  object_name(@@PROCID);
	declare @template as varchar(100) 
			, @result as int =0 
    SELECT @template = template_name 
    from [static].[Template]
	where template_id = @template_id 
--   exec dbo.log @transfer_id, '-------', '--------------------------------------------------------------------------------'
   declare @transfer_name as varchar(255) = 'push '+ @full_obj_name + isnull(' [' + convert(varchar(10), @template)+ ']' ,'') 
	, @is_running_in_batch as bit = 0
	, @status as varchar(100) = 'success'
	--, @transfer_id as int =0 
   if @batch_id>0 -- meaning: a batch_id was given as parameter.
	  set @is_running_in_batch=1
   --exec dbo.start_batch @batch_id output, @transfer_name
   exec dbo.start_transfer @batch_id output , @transfer_id output , @transfer_name
	-- standard BETL header code... 
	exec dbo.log @transfer_id, 'header', '? ?(?) batch_id ? transfer_id ? template_id ?', @proc_name , @full_obj_name, @scope, @batch_id, @transfer_id, @template_id
	if @transfer_id = 0 
	begin
		set @status= 'skipped' --  select * from betl.static.status
		exec dbo.log @transfer_id, 'info', 'transfer_id is zero->skipping push'
		goto footer
	end
	--exec dbo.my_info
	declare @log_level as varchar(255) =''
		, @exec_sql as varchar(255) =''
	exec [dbo].[getp] 'log_level', @log_level output 
	exec [dbo].[getp] 'exec_sql', @exec_sql output 
	exec dbo.log @transfer_id, 'info', 'log_level ?, exec_sql ? ', @log_level , @exec_sql
	-- END standard BETL header code... 
	declare 
			-- source
			@betl varchar(100) =db_name() 
			, @obj_id as int
			, @obj_name as varchar(255) 
			, @prefix as varchar(255) 
			, @obj_name_no_prefix as varchar(255) 
			, @default_template_id smallint
			, @obj_type as varchar(255) 
			, @srv as varchar(255)
			, @db as varchar(255) 
			, @schema as varchar(255) 
			, @schema_id as int 
			, @cols_pos int = 1
			, @cols dbo.ColumnTable
			, @cols_str varchar(4000) 
			, @attr_cols_str varchar(4000) 
			, @src_col_str varchar(4000) 
			, @compare_col_str_src varchar(4000) 
			, @compare_col_str_trg varchar(4000) 
			, @key_domain_id varchar(20) = ''
--			, @nat_prim_keys ColumnTable
			, @nat_prim_keys_str varchar(4000)
			, @nat_prim_key1 varchar(255) 
			, @nat_prim_key_match as varchar(4000) 
			, @trg_col_listing_str varchar(4000)
			, @src_col_value_str varchar(4000)
			, @sur_pkey1 varchar(255) 
			, @nat_fkey_match as varchar(4000) 
--			, @attribute_match_str varchar(4000) 
			-- target
			, @trg_obj_id as int
			, @trg_full_obj_name as varchar(255) 
			, @trg_obj_name as varchar(255) 
			, @trg_prefix as varchar(255) 
			--, @trg_obj_schema_name as varchar(255) 
			, @trg_srv as varchar(255)
			, @trg_db as varchar(255) 
			, @trg_schema as varchar(255) 
			, @trg_schema_id as int 
			, @trg_location as varchar(1000) 
			, @trg_cols dbo.ColumnTable
			, @trg_scope as varchar(255) 
			, @trg_entity_name as varchar(255) 
			-- mapping (copy columns from source to target)
			, @col_mapping_src dbo.ColumnTable
			, @col_mapping_trg dbo.ColumnTable
			, @col_mapping_src_str as varchar(4000)
			, @col_mapping_src_str_delete_detectie as varchar(4000)
			, @col_mapping_trg_str as varchar(4000)
			-- lookup
			, @lookup_entity_name as varchar(255) 
			, @lookup_index AS INT 
			, @lookup_col_listing_str AS VARCHAR(4000) 
			, @trg_join_str AS VARCHAR(4000) 
			-- hub
			, @hub_name as varchar(255) 
			, @lookup_hub_or_link_name as varchar(255) 
			, @sat_name as varchar(255) 
			, @link_name as varchar(255) 
			, @full_sat_name as varchar(255) 
			
			-- Dynamic SQL 
			, @nl as varchar(2) = char(13)+char(10)
			, @p as ParamTable
			, @sql as varchar(max) 
			, @sql2 as varchar(max) 
			, @sql_delete_detection as varchar(max) 
			, @lookup_sql AS varchar(max) 
			, @from as varchar(max) 
			, @from2 as varchar(max) 
			, @trg_cols_str varchar(max) 
			, @insert_cols_str varchar(max) 
			, @key_domain_sql as varchar(max)  = ''
			, @key_domain_match as varchar(255)  = ''
			, @key_domain_match_upd_old_sat as varchar(255) = ''
				-- properties
			, @is_linked_server as bit 
			, @date_datatype_based_on_suffix as bit
			, @is_localhost as bit 
			, @has_synonym_id as bit 
			, @has_record_dt as bit
			, @has_record_user as bit 
			, @etl_meta_fields as bit
			, @recreate_tables as bit
			, @use_key_domain as bit
			, @delete_detection as bit=0 
			, @filter_delete_detection as varchar(255) 
			
			-- other
			, @current_db varchar(255) 	
			, @ordinal_position_offset int 
			, @transfer_start_dt as datetime
			, @catch_sql as varchar(4000) 
			, @msg as varchar(255) = 'error in '+@proc_name
			, @sev as int = 15
			, @number as int =0
	if charindex('%', @full_obj_name )  >0 
	begin
		exec @result = dbo.push_all     
			@full_obj_name 
			, @batch_id 
			, @template_id 
			, @scope 
			, @transfer_id  -- stay within same transfer
		goto footer
	end
	select @current_db = db_name() 
	if @transfer_start_dt is null or @transfer_start_dt < '2016-01-01' -- meaning: very old 
		set @transfer_start_dt  = getdate() 
    ----------------------------------------------------------------------------
	exec dbo.log @transfer_id, 'STEP', 'retrieve obj_id from name ?', @full_obj_name
	----------------------------------------------------------------------------
	exec dbo.inc_nesting
	exec dbo.get_obj_id @full_obj_name, @obj_id output, @scope=@scope, @transfer_id=@transfer_id
	exec dbo.dec_nesting
	if @obj_id is null or @obj_id < 0 
	begin
		set @status= 'error' --  select * from betl.static.status
		exec dbo.log @transfer_id, 'error',  'object ? not found.', @full_obj_name
		goto footer
	end
	else 
		exec dbo.log @transfer_id, 'step' , 'obj_id resolved: ?', @obj_id 
	
	exec dbo.update_transfer @transfer_id=@transfer_id, @src_obj_id = @obj_id  
	-- first-> refresh the meta data of @obj_id
	exec dbo.inc_nesting
	exec dbo.refresh_obj_id @obj_id= @obj_id, @transfer_id = @transfer_id  -- refresh schema again. add trg to meta data. 
	exec dbo.dec_nesting
	-- get all required src meta data 
	select 
	@obj_type = obj_type
	, @obj_name = [obj_name]
	, @prefix = [prefix]
	, @obj_name_no_prefix = [obj_name_no_prefix]
	, @default_template_id = default_template_id 
	, @srv = srv
	, @db = db
	, @schema = [schema] 
	, @is_linked_server = dbo.get_prop_obj_id('is_linked_server', @obj_id) 
	, @date_datatype_based_on_suffix = dbo.get_prop_obj_id('date_datatype_based_on_suffix', @obj_id) 
	, @is_localhost = dbo.get_prop_obj_id('is_localhost', @obj_id) 
	, @trg_schema_id = dbo.get_prop_obj_id('target_schema_id', @obj_id) 
	, @delete_detection = dbo.get_prop_obj_id('delete_detection', @obj_id ) 
	, @filter_delete_detection = dbo.get_prop_obj_id('filter_delete_detection', @obj_id ) 
	, @full_obj_name = full_obj_name
	, @template_id = case when isnull(@template_id,0) =0 then dbo.get_prop_obj_id('template_id', @obj_id)   else @template_id end -- don't overwrite when specified in proc call
	from dbo.obj_ext 
	where [obj_id] = @obj_id 
	IF ISNULL(@template_id,0)  = 0  -- no transfermethod known-> take default 
		SET @template_id = @default_template_id
	
	exec dbo.log @transfer_id, 'VAR', '@template_id ? ', @template_id
	IF @prefix = 'stgh' AND @template_id NOT IN (8,9) 
	BEGIN 
		set @status= 'error' --  select * from betl.static.status
		exec dbo.log @transfer_id, 'error',  'object ? is a hub/hubsat staging table and thus needs transfermethod 8 or 9.', @full_obj_name
		goto footer
	END
	IF @prefix = 'stgl' AND @template_id NOT IN (10,11) 
	BEGIN 
		set @status= 'error' --  select * from betl.static.status
		exec dbo.log @transfer_id, 'error',  'object ? is a link/hubsat staging table and thus needs transfermethod 10 or 11.', @full_obj_name
		goto footer
	END
	IF @prefix = 'stgd' AND @template_id NOT IN (12) 
	BEGIN 
		set @status= 'error' --  select * from betl.static.status
		exec dbo.log @transfer_id, 'error',  'object ? is a dimension staging table and thus needs transfermethod 12.', @full_obj_name
		goto footer
	END
	
	IF @prefix = 'stgf' AND @template_id NOT IN (13,14) 
	BEGIN 
		set @status= 'error' --  select * from betl.static.status
		exec dbo.log @transfer_id, 'error',  'object ? is a fact staging table and thus needs transfermethod 13 or 14.', @full_obj_name
		goto footer
	END
	if @obj_type not in ('table', 'view') 
	begin 
		set @status= 'error' --  select * from betl.static.status
		exec dbo.log @transfer_id, 'ERROR', 'You can only push tables and views currently, no ?', @obj_type 
		goto footer
	END
    
    if @trg_schema_id is null 
	begin
		set @status= 'error' --  select * from betl.static.status
		exec dbo.log @transfer_id, 'error',  'Unable to determine target: No target schema specified'
		goto footer
	end 
    if not isnull(@template_id,0) > 0
	begin
		set @status= 'error' --  select * from betl.static.status
		exec dbo.log @transfer_id, 'error',  'No template specified for ?. please run ''exec ?.dbo.setp ''template_id'' , <template_id>, <full_obj_name>'' ', @full_obj_name, @betl 
		goto footer
	end 
    ----------------------------------------------------------------------------
	exec dbo.log @transfer_id, 'STEP', 'retrieving source columns'
	----------------------------------------------------------------------------
	insert into @cols 
	select * from dbo.get_cols(@obj_id)
	 -- select * from @cols 
	 -- do some checks...
	 if ( select count(*) from @cols WHERE column_type_id=100 ) = 0  and @template_id=8 -- we need >0 nat_pkey
	 begin
		set @status= 'error' --  select * from betl.static.status
		exec dbo.log @transfer_id, 'error',  'natural primary keys not found for ?. Please set column_type_id 100 in [dbo].[Col_ext].', @full_obj_name
		goto footer
	END
	 if ( select count(*) from @cols WHERE column_type_id=110 ) = 0  and @template_id=10 -- we need >0 nat_pkey
	 BEGIN 
		set @status= 'error' --  select * from betl.static.status
		exec dbo.log @transfer_id, 'error',  'natural foreign keys not found for ?. Please set column_type_id 110 in [dbo].[Col_ext].', @full_obj_name
		goto footer
	 END
	 if ( select count(*) from @cols WHERE column_type_id=300 ) = 0  and @template_id in (9) -- we need >0 attributes
	 BEGIN 
		exec dbo.log @transfer_id, 'INFO',  'Satelite contains no attributes and will not be created. @full_obj_name=?', @full_obj_name
		goto footer
	 END
 	 if ( select count(*) from @cols WHERE column_name='etl_data_source' ) = 0  and @template_id in (8,9,10,11) 
	 BEGIN 
		set @status= 'error' --  select * from betl.static.status
		exec dbo.log @transfer_id, 'ERROR',  'etl_data_source is a required column for hubs,links and sats. Please add this to your source table ?', @full_obj_name
		goto footer
	 END
    ----------------------------------------------------------------------------
	exec dbo.log @transfer_id, 'STEP', 'determine target table name'
	----------------------------------------------------------------------------
	select
	 @trg_obj_name = @obj_name_no_prefix
	, @srv = [srv]
	, @trg_db = [db]
	, @trg_schema = [schema]
	, @trg_srv = [srv]
	, @trg_scope = [scope]
	from dbo.obj_ext
	where [obj_id] = @trg_schema_id  -- must exist (FK) 
	exec dbo.log @transfer_id, 'VAR', '@trg_obj_name ? ', @trg_obj_name
	exec dbo.log @transfer_id, 'VAR', '@trg_schema_id ? ', @trg_schema_id
	set @trg_location = isnull('['+ case when @trg_srv='LOCALHOST' then null else @trg_srv end + '].','') + isnull('['+@trg_db+'].','') + isnull('['+@trg_schema+']','') 
	set @trg_prefix = 
	case 
		when @template_id = 4 then 'imp_' + @schema
		when @template_id = 5 then 'stgh'
		when @template_id = 8 then 'hub'
		when @template_id in (9,11) then 'sat'
		when @template_id = 10 then 'link'
		when @template_id = 12 then 'dim'
		when @template_id in ( 13, 14 ) then 'feit'
	end  + '_' 
	if @template_id = 5 
		set @trg_obj_name = replace(@trg_obj_name, 'imp_' ,'') 
	
	set @lookup_hub_or_link_name = CASE WHEN @template_id IN (8 ,9) THEN 'hub_'+ isnull(@trg_obj_name,'') 
										WHEN @template_id IN (10,11) THEN 'link_'+ isnull(@trg_obj_name,'') 
									END 
	set @lookup_hub_or_link_name = @trg_location + '.[' + isnull( @lookup_hub_or_link_name ,'') +']'
	set @trg_obj_name    = isnull(@trg_prefix,'') + isnull(@trg_obj_name,'') 
	set @trg_full_obj_name = @trg_location + '.[' + isnull(@trg_obj_name,'') +']'
	set @full_sat_name = isnull(@trg_prefix,'')  + '.[' + isnull(@sat_name,'') +']'
	exec dbo.log @transfer_id, 'STEP', 'push will copy ?(?) to ?(?) using template ?', @full_obj_name, @obj_id, @trg_full_obj_name, @trg_obj_id, @template_id
	select
		@has_synonym_id= dbo.get_prop_obj_id('has_synonym_id', @trg_schema_id ) 
		, @has_record_dt = dbo.get_prop_obj_id('has_record_dt', @trg_schema_id ) 
		, @has_record_user = dbo.get_prop_obj_id('has_record_user', @trg_schema_id ) 
		, @etl_meta_fields = dbo.get_prop_obj_id('etl_meta_fields', @trg_schema_id) 
		, @recreate_tables = dbo.get_prop_obj_id('recreate_tables', @trg_schema_id ) 
		--, @use_key_domain = dbo.get_prop_obj_id('use_key_domain', @trg_schema_id) 
	set @trg_entity_name = @obj_name_no_prefix
    ----------------------------------------------------------------------------
	exec dbo.log @transfer_id, 'STEP', 'determine key_domain'
	----------------------------------------------------------------------------
	set @use_key_domain  = dbo.get_prop_obj_id('use_key_domain', @obj_id) 
	if isnull(@use_key_domain,0) = 0 
	begin 
		with q as( 
			select foreign_cols.full_obj_name, convert( int, dbo.get_prop_obj_id('use_key_domain', foreign_cols.obj_id) )  use_key_domain
			FROM @cols cols
			INNER JOIN [dbo].[Col_ext] [foreign_cols] ON cols.[foreign_sur_pkey] = foreign_cols.column_id
			WHERE cols.column_type_id = 110 -- nat_fkey 
		) 
		select @use_key_domain  = use_key_domain
		from q 
		where use_key_domain=1 
	end
	
	exec dbo.log @transfer_id, 'VAR', '@use_key_domain ? ', @use_key_domain
	
    ----------------------------------------------------------------------------
	exec dbo.log @transfer_id, 'STEP', 'determine target columns'
	----------------------------------------------------------------------------
	if @template_id in (4)  -- create etl_data_source col
		insert into @cols ( [ordinal_position]					, [column_name]		, [column_value]	, data_type		, max_len , column_type_id ,is_nullable , src_mapping) 
		values ( (select max(ordinal_position)+1 from @cols)	,  'etl_data_source',  null,       'varchar'	, 10 , 999				, 0,  replace(@schema, 'medcare', 'mc'))  
		-- 300 instead of 999 because 999 is skipped

	if @template_id in ( 1,4,5)  -- T/I 
		insert into @trg_cols
		select * from @cols
		where not ( @template_id = 5 and column_type_id=999 and column_name <> 'etl_data_source') -- skip meta data for template 5 except etl_Data_source
	-- create sur_pkey 
	if @template_id=8 -- hub
		insert into @trg_cols(ordinal_position,column_name,column_value,data_type,max_len,is_nullable
		, [entity_name] ,[numeric_precision] ,[numeric_scale] , column_type_id, [identity]) 
		values ( 1, 'hub_'+ lower(@trg_entity_name) + '_sid', null, 'int', null, 0, null, null, null, 200,1 ) -- sur_pkey
	if @template_id=10 -- link
		insert into @trg_cols(ordinal_position,column_name,column_value,data_type,max_len,is_nullable
		, [entity_name] ,[numeric_precision] ,[numeric_scale] , column_type_id, [identity]) 
		values ( 1, 'link_'+ lower(@trg_entity_name) + '_sid', null, 'int', null, 0, null, null, null, 200,1 ) -- sur_pkey
	set @ordinal_position_offset = 1
	if @template_id IN (9,11)  -- sat
	begin
		insert into @trg_cols(ordinal_position,column_name,column_value,data_type,max_len,is_nullable
		, [entity_name] ,[numeric_precision] ,[numeric_scale] , column_type_id, [identity]) 
		values ( 1, 'sat_'+ lower(@trg_entity_name) + '_sid', null, 'int', null, 0, null, null, null, 200,1 ) -- sur_pkey
		IF @template_id =9 
			insert into @trg_cols(ordinal_position,column_name,column_value,data_type,max_len,is_nullable
			, [entity_name] ,[numeric_precision] ,[numeric_scale] , column_type_id, src_mapping) 
			values ( 2, 'hub_'+ lower(@trg_entity_name) + '_sid', null, 'int', null, 0, null, null, null, 210, 'trg.[hub_'+ lower(@trg_entity_name) + '_sid]') 
		IF @template_id =11 
			insert into @trg_cols(ordinal_position,column_name,column_value,data_type,max_len,is_nullable
			, [entity_name] ,[numeric_precision] ,[numeric_scale] , column_type_id, src_mapping) 
			values ( 2, 'link_'+ lower(@trg_entity_name) + '_sid', null, 'int', null, 0, null, null, null, 210, 'trg.[link_'+ lower(@trg_entity_name) + '_sid]') 
		set @ordinal_position_offset = 2
	end
	-- add link sur_fkey
	INSERT into @trg_cols(ordinal_position,column_name,column_value,data_type,max_len,column_type_id, is_nullable
	, [entity_name] ,[numeric_precision] ,[numeric_scale] , [part_of_unique_index], [src_mapping]) 
	select row_number() over (order by c.ordinal_position) + @ordinal_position_offset
			,  CASE WHEN ISNULL(c.prefix,'') = '' THEN '' ELSE c.prefix+ '_' END 
				+ ISNULL(sur_fkey.column_name, 'invalid_sur_fkey') column_name 
			, null
			, sur_fkey.data_type
			, sur_fkey.[max_len] 
			, 210
			, 1 [is_nullable]
			, c.[entity_name]
			, sur_fkey.[numeric_precision] 
			, sur_fkey.[numeric_scale] 
			, 1 part_of_unique_index
			, 'trg.'+quotename( CASE WHEN ISNULL(c.prefix,'') = '' THEN '' ELSE c.prefix+ '_' END 
				+ ISNULL(sur_fkey.column_name, 'invalid_sur_fkey') ) 
	from @cols c -- identical 
	INNER JOIN dbo.Col sur_fkey ON sur_fkey.column_id = c.[foreign_sur_pkey] -- get [foreign_sur_pkey] details
	where 
		( @template_id IN ( 10,11)  and c.column_type_id in ( 110) ) -- links sur_fkey
	order by c.ordinal_position asc
	SELECT @ordinal_position_offset = isnull(MAX(ordinal_position) ,0) 
	FROM @trg_cols 
	insert into @trg_cols(ordinal_position,column_name,column_value,data_type,max_len,column_type_id, is_nullable
	, [entity_name] ,[numeric_precision] ,[numeric_scale] , [part_of_unique_index] , [src_mapping]) 
	select row_number() over (order by ordinal_position) + @ordinal_position_offset
			, column_name 
			, column_value
			,case when @date_datatype_based_on_suffix=1 and util.suffix(column_name, 5) = '_date' then 
				'date' else [data_type]  end 
			, [max_len] 
			, case 
					when [util].[prefix_first_underscore]( column_name ) = 'dkey' and @template_id = 12 
						and ordinal_position = 1 -- dim 
					then 200 
					when [util].[prefix_first_underscore]( column_name ) = 'fkey' and @template_id in (13,14)
						and ordinal_position = 1 -- feit
					then 200 
					when [util].[prefix_first_underscore]( column_name ) = 'dkey' and @template_id = 12 
						and ordinal_position > 1 -- dim 
					then 210 
					when [util].[prefix_first_underscore]( column_name ) = 'dkey' and @template_id in ( 13,14)  -- feit
					then 210 

					else column_type_id end  column_type_id 

			,case when column_type_id in (100, 200, 210) then 0 else [is_nullable] end
			,case when column_type_id in (210) then @trg_entity_name else [entity_name]  end 
			,[numeric_precision] 
			,[numeric_scale] 
			, CASE 
				WHEN @template_id in (8,9) AND column_type_id in (100, 110)  THEN 1 
				WHEN @template_id in (10,11) AND column_type_id in (100)  THEN 1 ELSE 0 END [part_of_unique_index] -- link and link sats only nat_pkeys
			, 'src.'+quotename(column_name) 
	from @cols c -- identical 
	where 
			( @template_id = 8 and column_type_id in ( 100) ) -- hubs
		or ( @template_id IN (9,11)  and column_type_id in ( 100, 300) ) -- sats
		OR ( @template_id IN (10,11)  and column_type_id in ( 100, 110) ) -- link attributes 
		OR ( @template_id IN (12,13,14)  ) -- facts and dims
	order by ordinal_position asc
	
	SELECT @ordinal_position_offset = MAX(ordinal_position) 
	FROM @cols 
	if @use_key_domain =1 
	begin
		if @template_id IN (8,9)   -- hubs and links
        	INSERT into @trg_cols ( [ordinal_position]					, [column_name]		, [column_value]	, data_type		, max_len , column_type_id ,is_nullable, [part_of_unique_index] , src_mapping) 
			VALUES ( (select max(ordinal_position)+1 from @trg_cols)	,  'key_domain_id'	, null				, 'int'	, NULL	  , 100			, 0 , 1, 'isnull(src.[key_domain_id],-1) key_domain_id') 
		if @template_id IN (10,11)   -- hubs and links
        	INSERT into @trg_cols ( [ordinal_position]					, [column_name]		, [column_value]	, data_type		, max_len , column_type_id ,is_nullable, [part_of_unique_index] , src_mapping) 
			VALUES ( (select max(ordinal_position)+1 from @trg_cols)	,  'key_domain_id'	, null				, 'int'	, NULL	  , 300			, 0 , 0, 'isnull(src.[key_domain_id],-1) key_domain_id') 

		--if @template_id IN (9,11)   -- hubs and links
  --      	INSERT into @trg_cols ( [ordinal_position]					, [column_name]		, [column_value]	, data_type		, max_len , column_type_id ,is_nullable, [part_of_unique_index] , src_mapping) 
		--	VALUES ( (select max(ordinal_position)+1 from @trg_cols)	,  'key_domain_id'	, null				, 'int'	, NULL	  , 100			, 0 , 1, 'isnull(src.[key_domain_id],-1) key_domain_id') 
	
		set @key_domain_sql = 'left join <betl>.dbo.Key_domain kd on src.etl_data_source = kd.key_domain_name'
	end
	if @etl_meta_fields =1 
	begin
		if @template_id IN (8,9,10,11)  -- hub sats and link sats
			and not exists ( select * from 	@trg_cols where column_name = 'etl_data_source' ) -- not already present (via column_type). 
			insert into @trg_cols ( [ordinal_position]					, [column_name]		, [column_value]	, data_type		, max_len , column_type_id ,is_nullable , src_mapping) 
			values ( (select max(ordinal_position)+1 from @trg_cols)	,  'etl_data_source',  null,       'varchar'	, 10 , 999				, 0, 'src.etl_data_source') 
		if @template_id IN (9,11)   -- hub sats and link sats
		begin
			insert into @trg_cols ( [ordinal_position]					, [column_name]		, [column_value]	, data_type		, max_len , column_type_id ,is_nullable) 

			values ( (select max(ordinal_position)+1 from @trg_cols)	,  'etl_active_flg'	, 1					, 'bit'			, NULL	  , 999				, 0) 
        	INSERT into @trg_cols ( [ordinal_position]					, [column_name]		, [column_value]	, data_type		, max_len , column_type_id ,is_nullable, [part_of_unique_index] , src_mapping) 
			VALUES ( (select max(ordinal_position)+1 from @trg_cols)	,  'etl_load_dt'	, null				, 'datetime'	, NULL	  , 100			, 0 , 1, '''<transfer_start_dt>''') 
			insert into @trg_cols ( [ordinal_position]					, [column_name]		, [column_value]	, data_type		, max_len , column_type_id ,is_nullable) 
			values ( (select max(ordinal_position)+1 from @trg_cols)	,  'etl_end_dt'	,  '''2999-12-31'''		, 'datetime'	, NULL	  , 999				, 0) 
		end
		else
			if @template_id not IN (5) 
        		INSERT into @trg_cols ( [ordinal_position]					, [column_name]		, [column_value]	, data_type		, max_len , column_type_id ,is_nullable, [part_of_unique_index] , src_mapping) 
				VALUES ( (select max(ordinal_position)+1 from @trg_cols)	,  'etl_load_dt'	, null				, 'datetime'	, NULL	  , 999			, 0 , 0, '''<transfer_start_dt>''') 
		
		if @template_id IN (9,11)  -- hub sats and link sats
			insert into @trg_cols ( [ordinal_position]					, [column_name]		, [column_value]	, data_type		, max_len , column_type_id ,is_nullable) 
			values ( (select max(ordinal_position)+1 from @trg_cols)	,  'etl_deleted_flg'	, 0				, 'bit'			, NULL	  , 999				, 0) 
		if @template_id not IN (5) 
			insert into @trg_cols ( [ordinal_position]					, [column_name]		, [column_value]	, data_type		, max_len , column_type_id ,is_nullable, src_mapping) 
			values ( (select max(ordinal_position)+1 from @trg_cols)	,  'etl_transfer_id'		, null				, 'int'			, NULL	  , 999				, 0, '<transfer_id>') 
	end
					
	if @has_synonym_id=1 
		insert into @trg_cols ( [ordinal_position]					, [column_name]		, [column_value]	, data_type		, max_len , column_type_id ,is_nullable) 
		values ( (select max(ordinal_position)+1 from @trg_cols)	,  'synonym_id'		, null				, 'int'			, NULL	  , 999				, 1) 
	if @has_record_dt =1 
		insert into @trg_cols ( [ordinal_position]					, [column_name]		, [column_value]	, data_type		, max_len , column_type_id ,is_nullable) 
		values ( (select max(ordinal_position)+1 from @trg_cols)	,  'etl_record_dt'	, 'getdate()'		, 'datetime'	, NULL	  , 999				, 0) 
	if @has_record_user =1 and @template_id<> 5
		insert into @trg_cols ( [ordinal_position]					, [column_name]		, [column_value]			, data_type		, max_len , column_type_id ,is_nullable) 
		values ( (select max(ordinal_position)+1 from @trg_cols)	,  'etl_record_user'	, 'suser_sname()'		, 'varchar'		, 255	  , 999				, 0) 
    ----------------------------------------------------------------------------
	exec dbo.log @transfer_id, 'STEP', 'create table or view ddl'
	----------------------------------------------------------------------------
	declare @create_pkey as bit 
	set @create_pkey = case when @template_id >= 12 then 1 else 0 end 
	
	if @template_id=5 
		exec create_view @trg_full_obj_name, @trg_scope, @trg_cols, @full_obj_name, @transfer_id
	else 
		exec create_table @trg_full_obj_name, @trg_scope, @trg_cols, @transfer_id, @create_pkey
	exec dbo.inc_nesting 
	exec dbo.refresh_obj_id @obj_id= @trg_schema_id, @transfer_id = @transfer_id  -- refresh schema again. add trg to meta data. 
	exec dbo.get_obj_id @trg_full_obj_name , @trg_obj_id output, @trg_scope, @transfer_id
	exec dbo.dec_nesting
	if @trg_obj_id is null 
	begin
		set @status= 'error' --  select * from betl.static.status
		exec dbo.log @transfer_id, 'error',  'object ?(?) cannot be created', @trg_full_obj_name, @trg_scope
		goto footer
	end
	if @template_id=4
		set @scope = @schema -- set scope = source schema. e.g. adapt 
	if @template_id in (4,5) -- set scope in betl base
	begin
		update betl.dbo.Obj_ext
		set scope = @scope
		where [obj_id] = @trg_obj_id 
	end 
	if @template_id=5 -- nothing more todo
	begin
		exec dbo.inc_nesting
		exec dbo.refresh @full_obj_name = @trg_full_obj_name , @transfer_id = @transfer_id
		exec dbo.dec_nesting
		select @trg_full_obj_name trg_full_obj_name
		exec betl.dbo.update_transfer @transfer_id, @target_name = @trg_full_obj_name
		goto footer
	end
    ----------------------------------------------------------------------------
	exec dbo.log @transfer_id, 'STEP', 'column mappings old'
	----------------------------------------------------------------------------
	 set @cols_str = ''
	 select @cols_str+=case when @cols_str='' then '' else ',' end + isnull('"'+ src_mapping +'"', 'src.'+quotename(column_name) ) 
	 from @cols
	 -- where column_type_id <> 999 -- no meta cols
	 order by ordinal_position asc

	 SET @attr_cols_str=''
	 select @attr_cols_str+= 'src.'+quotename(column_name)  + ','
	 from @cols
	 where column_type_id = 300
	 order by ordinal_position asc
	 	 
	set @nat_prim_keys_str=''
	select @nat_prim_keys_str+=case when @nat_prim_keys_str='' then '' else ',' end + 'src.'+column_name
	from @cols WHERE column_type_id=100 and column_name <> 'etl_data_source'
	order by ordinal_position asc
	if @use_key_domain=1 
		set @nat_prim_keys_str+= case when @nat_prim_keys_str='' then '' else ',' end + ' isnull(kd.key_domain_id,-1)' 
	set @src_col_value_str=''
	select @src_col_value_str+=case when @src_col_value_str='' then '' else ',' end + 'src.'+column_name
	from @cols WHERE column_type_id in ( 100,110) 
	set @trg_col_listing_str=''
	select @trg_col_listing_str+=case when @trg_col_listing_str='' then '' else ',' end + column_name
	from @cols WHERE column_type_id in ( 100,110) 
	if @use_key_domain=1 
	begin
		set @src_col_value_str+= case when @src_col_value_str='' then '' else ',' end + 'isnull(kd.key_domain_id,-1)' 
		set @trg_col_listing_str+= case when @trg_col_listing_str='' then '' else ',' end + 'key_domain_id' 
	end
	select @nat_prim_key1 = column_name
	from @cols 

	WHERE column_type_id in ( 100,110) 

	AND ordinal_position = ( select min(ordinal_position ) from @cols WHERE column_type_id in ( 100,110)  ) 
	--build @nat_prim_key_match 
	set @nat_prim_key_match =''
	select @nat_prim_key_match += case when @nat_prim_key_match ='' then 'src.' else ' AND src.' end 
	+  cols.column_name + ' = trg.' + cols.column_name 
	from @cols cols
	where ( column_type_id = 100 AND @template_id in (8, 9)   )  OR 
		  ( column_type_id in (100, 110)  AND @template_id in (10, 11) )  
	 -- natprim_keys 
	 if @use_key_domain = 1 
	 begin
		if @template_id in (8,10) 
		begin
			set @key_domain_match = ' AND isnull(kd.key_domain_id,-1) = trg.key_domain_id '
			set	@key_domain_match_upd_old_sat = ' And src.key_domain_id = trg.key_domain_id '
			set @key_domain_id = ', key_domain_id'
		end
		--	set @key_domain_match_del = ' And kd.key_domain_id = src.key_domain_id '
		if @template_id in (9,11)  
		begin
			set @key_domain_match = ' AND isnull(kd.key_domain_id,-1) = trg.key_domain_id '
			set	@key_domain_match_upd_old_sat = ' And src.key_domain_id = trg.key_domain_id '
			set @key_domain_id = ', key_domain_id'
		end
		--	set @key_domain_match_del = ' And kd.key_domain_id = src.key_domain_id '
	end
	select @sur_pkey1 = column_name
	from @trg_cols
	where column_type_id = 200 AND ordinal_position = ( select min(ordinal_position ) from @trg_cols WHERE column_type_id=200 ) 
	set @nat_fkey_match =''
	select @nat_fkey_match += case when @nat_fkey_match ='' then 'src.' else ' AND src.' end 
	+  cols.column_name + ' = trg.' + cols.column_name 
	from @cols cols
	where column_type_id = 110 -- natfkeys 
	set @trg_cols_str=''
	--set @trg_cols_str_met_alias=''
	select @trg_cols_str+=case when @trg_cols_str='' then '' else ',' end + quotename(column_name )
		--, @trg_cols_str_met_alias+=case when @trg_cols_str_met_alias='' then '' else ',' end + 'trg.'+ quotename(column_name) 
	from @trg_cols
		where 
		( 
		  ( column_type_id in ( 100, 210, 300) and @template_id in ( 10)  ) or 
		  ( column_type_id in ( 100, 110, 300) and @template_id IN ( 9,11)  ) or 
		  ( column_type_id in ( 100) and @template_id=8 )  or
		  ( @template_id in (1,4,12,13,14)  ) 
		  or ( column_name ='etl_data_source' )  
		) AND column_name not in (  'etl_load_dt', 'etl_transfer_id', 'etl_record_user')  -- added manually
	order by ordinal_position asc
	set @insert_cols_str=@trg_cols_str
	if @use_key_domain = 1 
	begin
		set @trg_cols_str = replace( @trg_cols_str, '[key_domain_id]',  'isnull([key_domain_id],-1) key_domain_id') 
	end
	exec dbo.log @transfer_id, 'var', 'cols_str ?', @cols_str
	exec dbo.log @transfer_id, 'var', 'trg_cols_str ?', @trg_cols_str
	exec dbo.log @transfer_id, 'var', 'insert_cols_str ?', @insert_cols_str
	exec dbo.log @transfer_id, 'var',  '@nat_prim_keys_str ?'    , @nat_prim_keys_str
	exec dbo.log @transfer_id, 'var',  '@nat_prim_key_match ?'   , @nat_prim_key_match
	exec dbo.log @transfer_id, 'var',  '@nat_prim_key1 ?'        , @nat_prim_key1 
	exec dbo.log @transfer_id, 'var',  '@src_col_value_str ?'  ,  @src_col_value_str
	exec dbo.log @transfer_id, 'var',  '@trg_col_listing_str ?'  ,  @trg_col_listing_str
	exec dbo.log @transfer_id, 'var',  '@nat_fkey_match ?' ,  @nat_fkey_match
	exec dbo.log @transfer_id, 'var',  '@sur_pkey1 ?'      ,  @sur_pkey1
    ----------------------------------------------------------------------------
	exec dbo.log @transfer_id, 'STEP', 'column mappings new'
	----------------------------------------------------------------------------
	set @col_mapping_trg_str = ''
	select @col_mapping_trg_str += 
		case when @col_mapping_trg_str = '' then '' else ',' end + quotename(column_name) 
	from @trg_cols
	where src_mapping is not null 
	set @col_mapping_src_str = ''
	select @col_mapping_src_str += 
		case when @col_mapping_src_str = '' then '' else ',' end + src_mapping
	from @trg_cols
	where src_mapping is not null 
	set @col_mapping_src_str = replace(@col_mapping_src_str , 'trg.', 'src.') 
	set @col_mapping_src_str_delete_detectie = replace(@col_mapping_src_str , 'src.', 'trg.') 
	set @compare_col_str_src = ''
	select @compare_col_str_src+=case when @compare_col_str_src='' then '' else ',' end + src_mapping
	from @trg_cols
	where column_type_id in ( 100, 110, 210, 300 ) -- cdc is done on these columns (actually only 300, but link-sats need at least something)
	and column_name <> 'etl_load_dt'
	or column_name = 'etl_data_source'
	order by ordinal_position asc
	set @compare_col_str_src = replace(@compare_col_str_src, 'src.[key_domain_id]','trg.[key_domain_id]' ) 
	set @compare_col_str_trg = replace(@compare_col_str_src, 'src.', 'trg.') 
	exec dbo.log @transfer_id, 'var',  '@col_mapping_src_str ?'      ,  @col_mapping_src_str
	exec dbo.log @transfer_id, 'var',  '@col_mapping_src_str_delete_detectie ?'      ,  @col_mapping_src_str_delete_detectie
	exec dbo.log @transfer_id, 'var',  '@col_mapping_trg_str ?'      ,  @col_mapping_trg_str
	exec dbo.log @transfer_id, 'var',  '@compare_col_str_src ?'			 ,  @compare_col_str_src
	
    ----------------------------------------------------------------------------
	exec dbo.log @transfer_id, 'STEP', 'build template sql'
	----------------------------------------------------------------------------
	set @catch_sql ='
		END TRY
		BEGIN CATCH
       			use <current_db>
				declare @msg_<obj_id>_<transfer_id> as varchar(255) =ERROR_MESSAGE() 
						, @sev_<obj_id>_<transfer_id> as int = ERROR_SEVERITY()
						, @number_<obj_id>_<transfer_id> as int = ERROR_NUMBER() 
				IF @@TRANCOUNT > 0
                      ROLLBACK TRANSACTION
				set @status_id = 200				
				exec <betl>.dbo.update_transfer @transfer_id=<transfer_id>, @rec_cnt_src = @rec_cnt_src, @rec_cnt_new = @rec_cnt_new, @rec_cnt_changed=@rec_cnt_changed, @target_name = ''<trg_full_obj_name>'', @status_id =@status_id 
				exec dbo.log_error @transfer_id=<transfer_id>, @msg=@msg_<obj_id>_<transfer_id>,  @severity=@sev_<obj_id>_<transfer_id>, @number=@number_<obj_id>_<transfer_id> 

		END CATCH 
		if @status_id in ( 200, 300) 
			RAISERROR("push raised error" , 15 , 0)  WITH NOWAIT
		exec <betl>.dbo.update_transfer @transfer_id=<transfer_id>, @rec_cnt_src = @rec_cnt_src, @rec_cnt_new = @rec_cnt_new, @rec_cnt_changed=@rec_cnt_changed, @target_name = ''<trg_full_obj_name>'', @status_id =@status_id 
'
	exec dbo.log @transfer_id, 'STEP', 'build push sql'
	
	set @sql=''
	set @sql2 = '
---------------------------------------------------------------------------------------------------
-- start transfer method <template_id> <full_obj_name>(<obj_id>) to <trg_full_obj_name>(<trg_obj_id>)
---------------------------------------------------------------------------------------------------
select ''<trg_full_obj_name>'' trg_full_obj_name
'	
	  exec dbo.log @transfer_id, 'step', 'transfering ?(?) to ?(?) ', @full_obj_name, @obj_id, @trg_full_obj_name, @trg_obj_id
	  if @is_linked_server = 1 
	     set @from = 'openquery(<srv>, "select count(*) cnt from <full_obj_name> ") '
	  else 
		set @from = 'select count(*) cnt from <full_obj_name>'
	
	delete from @p
	insert into @p values ('betl'					, @betl) 
	insert into @p values ('full_obj_name'		, @full_obj_name) 
	insert into @p values ('trg_full_obj_name'		, @trg_full_obj_name) 
	insert into @p values ('srv'					, @srv ) 
	insert into @p values ('trg_obj_id'				, @trg_obj_id) 
	insert into @p values ('template_id'			, @template_id) 
	insert into @p values ('batch_id'				, @batch_id ) 
	insert into @p values ('transfer_id'			, @transfer_id ) 
	insert into @p values ('obj_id'					, @obj_id) 
	insert into @p values ('current_db'				, @current_db) 
	EXEC util.apply_params @catch_sql output, @p
	insert into @p values ('catch_sql'				, @catch_sql) 
	EXEC util.apply_params @from output, @p
	insert into @p values ('from'					, @from) 
	EXEC util.apply_params @sql2 output, @p
	set @sql+= @sql2
	set @from2 = 'select <top> <cols> from <full_obj_name>'
	if @is_linked_server = 1 
	    set @from = 'openquery(<srv>, "<from2> ") '
	
	if @template_id in (1,4,12,13)   -- truncate insert
	begin 
		set @sql2 = '
BEGIN TRY 
	-- truncate insert
	use <trg_db>;
	declare @rec_cnt_src as int
		, @rec_cnt_new as int
		, @rec_cnt_changed as int
		, @status_id as int = 100 
	select @rec_cnt_src = ( select count(*) from <full_obj_name> src ) 
	use <trg_db>;
	truncate table <trg_full_obj_name>;
	insert into <trg_full_obj_name>(<insert_cols_str>, etl_transfer_id, etl_load_dt)
		select <cols_str>, <transfer_id>, ''<transfer_start_dt>''
		from <full_obj_name> src ;
	
	set @rec_cnt_new =@@rowcount
	use <current_db>
	
<catch_sql> 
' 
	end -- truncate insert
	if @template_id in (14)   -- append insert
	begin 
		set @sql2 = '
BEGIN try
	-- truncate insert
	use <trg_db>;
	declare @rec_cnt_src as int = ( select count(*) from <full_obj_name> src ) 
	use <trg_db>;
	insert into <trg_full_obj_name>(<insert_cols_str>, etl_transfer_id, etl_load_dt)

		select <cols_str>, <transfer_id>, ''<transfer_start_dt>''
		from <full_obj_name> src;
	set @rec_cnt_new = @@rowcount
	use <current_db>
<catch_sql> 
' 
	end -- truncate insert
	
	if @template_id=8 -- Datavault Hub  (CDC)
	begin
		--build HUB 
		set @sql2 = '
BEGIN TRY
	-- build HUB 
	use <trg_db>;
	declare @rec_cnt_src as int
			, @rec_cnt_new as int
			, @rec_cnt_changed as int
			, @status_id as int = 100 
	
	select  @rec_cnt_src  = ( select count(*) from <full_obj_name> src ) 
	-- insert new hub keys
	insert into <trg_full_obj_name>(<insert_cols_str>, etl_transfer_id, etl_load_dt)
		select distinct <nat_prim_keys_str>, src.etl_data_source, <transfer_id>, ''<transfer_start_dt>''
		from <full_obj_name> src
		<key_domain_sql>
		left join <trg_full_obj_name> trg on <nat_prim_key_match> <key_domain_match> 
		where trg.<nat_prim_key1> is null -- not exist
	set @rec_cnt_new =@@rowcount
<catch_sql> 
'
	end
	if @template_id IN ( 9,11)  -- Datavault Sat (CDC)
	begin
		-- build SAT
		set @sql2 = '
BEGIN TRY 
-- build SAT
use <trg_db>;
	declare @rec_cnt_src as int
			, @rec_cnt_new as int
			, @rec_cnt_changed as int
			, @status_id as int = 100 
set @rec_cnt_src = ( select count(*) from <full_obj_name> src ) 
use <trg_db>;
if object_id(N''[tempdb]..#src'', ''U'') is not null 
	drop table #src
select src.* 	into #src
	from ( 
		select <compare_col_str_src>
		from <full_obj_name> src
		<key_domain_sql>
		inner join <lookup_hub_or_link_name> trg on <nat_prim_key_match> <key_domain_match>
		except 
		select <compare_col_str_trg>
		from <trg_full_obj_name> trg
		where trg.etl_active_flg=1 and trg.etl_deleted_flg=0
	) src
	begin transaction 
	insert into <trg_full_obj_name>(<col_mapping_trg_str>)
	select <col_mapping_src_str> 
	from #src src
	--inner join <lookup_hub_or_link_name> trg on <nat_prim_key_match> <key_domain_match>
	declare @cnt_new_and_changed as int =@@rowcount
	-- end date old sat records
	update trg set etl_active_flg = 0, etl_end_dt = src.etl_load_dt
	from <trg_full_obj_name> trg
	inner join <trg_full_obj_name> src on <nat_prim_key_match> <key_domain_match_upd_old_sat> and src.etl_transfer_id = <transfer_id>
	where trg.etl_active_flg = 1 and trg.etl_load_dt < src.etl_load_dt
	set @rec_cnt_changed =@@rowcount	
	set @rec_cnt_new = isnull(@cnt_new_and_changed,0)  - isnull(@rec_cnt_changed , 0) 
	
	commit transaction 
<catch_sql> 
'
if @delete_detection=1 
	set @sql_delete_detection= '
	-- Apply delete detection 
	BEGIN TRY 
	use <trg_db>;
	declare @rec_cnt_src as int
		, @rec_cnt_new as int
		, @rec_cnt_changed as int
		, @status_id as int = 100 
		, @cnt as int
	select @cnt = count(*) from <full_obj_name> src 
	if @cnt = 0 
		goto footer
	begin transaction
	
	insert into <trg_full_obj_name>(<col_mapping_trg_str>, etl_deleted_flg)
		select <col_mapping_src_str_delete_detectie>, 1 etl_deleted_flg
		from <trg_full_obj_name> trg

		left join (select src.* <key_domain_id>
				   from <full_obj_name> src
				   <key_domain_sql> ) src
					on <nat_prim_key_match> <key_domain_match_upd_old_sat>
		where 
		trg.etl_active_flg = 1 and trg.etl_deleted_flg = 0 
		<filter_delete_detection>
		and src.<nat_prim_key1> is null -- key does not exist anymore in src
		declare @rec_cnt_deleted as int =@@rowcount
	-- end date old sat records
	update trg set etl_active_flg = 0, etl_end_dt = src.etl_load_dt
	from <trg_full_obj_name> trg
	inner join <trg_full_obj_name> src on <nat_prim_key_match>  <key_domain_match_upd_old_sat> and src.etl_transfer_id = <transfer_id>
		and src.etl_deleted_flg=1 
	where trg.etl_active_flg = 1 and trg.etl_load_dt < src.etl_load_dt
	commit transaction
	footer:
	exec <betl>.dbo.update_transfer @transfer_id=<transfer_id>, @rec_cnt_deleted=@rec_cnt_deleted
	<catch_sql> 
	' 
	else 
	set @sql_delete_detection= ' -- delete detection is disabled for <full_obj_name>'
	end
	if @template_id=10 -- Datavault Link 
	BEGIN
		SET @lookup_sql =''
		SET @lookup_col_listing_str =''
		SET @trg_join_str = ''
		SELECT @lookup_sql += 
		'INNER JOIN '
		+ foreign_cols.[full_obj_name] 
		+ ' as lookup_' + CONVERT(VARCHAR(25), cols.ordinal_position) 
		+ ' ON lookup_' + CONVERT(VARCHAR(25), cols.ordinal_position) +'.' + cols.[foreign_column_name] + ' = src.' + quotename(cols.column_name)
		+ case when dbo.get_prop_obj_id('use_key_domain', foreign_cols.obj_id) = 1 then  -- foreign hub has key domain column 
		' AND lookup_' + CONVERT(VARCHAR(25), cols.ordinal_position) +'.key_domain_id = isnull(kd.key_domain_id,-1)' else '' end  + '
		'
			, @trg_col_listing_str += CASE WHEN @trg_col_listing_str ='' THEN '' ELSE ',' END 
			+ CASE WHEN ISNULL(cols.prefix, '') <> '' THEN cols.prefix + '_' ELSE '' END + [foreign_cols].column_name + '
			'
			, @src_col_value_str += CASE WHEN @src_col_value_str ='' THEN '' ELSE ',' END 
			+'lookup_' + CONVERT(VARCHAR(25), cols.ordinal_position) +'.'+ [foreign_cols].column_name + ' as '  
			+ CASE WHEN ISNULL(cols.prefix, '') <> '' THEN cols.prefix + '_' ELSE '' END + [foreign_cols].column_name + '
			'
		
			, @trg_join_str += CASE WHEN @trg_join_str ='' THEN '' ELSE ' AND ' END 
			+'lookup_' + CONVERT(VARCHAR(25), cols.ordinal_position) +'.'+ [foreign_cols].column_name + 
			' = trg.' + CASE WHEN ISNULL(cols.prefix, '') <> '' THEN cols.prefix + '_' ELSE '' END + [foreign_cols].column_name 
		FROM @cols cols
		INNER JOIN [dbo].[Col_ext] [foreign_cols] ON cols.[foreign_sur_pkey] = foreign_cols.column_id
		WHERE cols.column_type_id in (110) -- nat_fkey 
		select 
			@trg_join_str += CASE WHEN @trg_join_str ='' THEN '' ELSE ' AND ' END 
			+'src.'+ [cols].column_name + 
			' = trg.' + CASE WHEN ISNULL(cols.prefix, '') <> '' THEN cols.prefix + '_' ELSE '' END + [cols].column_name 
		FROM @cols cols
		WHERE cols.column_type_id in (100) -- nat_pkey 
		exec dbo.log @transfer_id, 'var',  '@trg_col_listing_str ?'  ,  @trg_col_listing_str

		exec dbo.log @transfer_id, 'var',  '@trg_join_str ?'  ,  @trg_join_str
		set @sql2 = '
BEGIN TRY
-- build LINK
use <trg_db>;
	declare @rec_cnt_src as int
			, @rec_cnt_new as int
			, @rec_cnt_changed as int
			, @status_id as int = 100 
set @rec_cnt_src = ( select count(*) from <full_obj_name> src ) 
-- insert new link keys
insert into <trg_full_obj_name>(<trg_col_listing_str>, etl_transfer_id, etl_load_dt, etl_data_source)
select <src_col_value_str>
, <transfer_id> etl_transfer_id
, ''<transfer_start_dt>'' etl_load_dt
, src.etl_data_source
from <full_obj_name> src
<key_domain_sql>
<lookup_sql>
left join <trg_full_obj_name> trg on <trg_join_str> 
where trg.<sur_pkey1> is null -- not exist
	
set @rec_cnt_new =@@rowcount
<catch_sql> 
---------------------------------------------------------------------------------------------------
-- end transfer method <template_id> <full_obj_name>(<obj_id>) to <trg_full_obj_name>(<trg_obj_id>)
---------------------------------------------------------------------------------------------------
'
	end
	
	--insert into @p values ('betl'					, @betl) 
	insert into @p values ('full_sat_name'				, @full_sat_name) 
	insert into @p values ('lookup_hub_or_link_name'	, @lookup_hub_or_link_name)  
	insert into @p values ('cols_str'					, @cols_str) 
	insert into @p values ('attr_cols_str'				, @attr_cols_str) 
	EXEC util.apply_params @key_domain_sql  output		 , @p
	insert into @p values ('key_domain_sql'				 , @key_domain_sql) 
	insert into @p values ('key_domain_match'			 , @key_domain_match) 
	insert into @p values ('key_domain_match_upd_old_sat', @key_domain_match_upd_old_sat)
	insert into @p values ('key_domain_id'				 , @key_domain_id)
	
	INSERT into @p values ('trg_cols_str'				, @trg_cols_str) 
	INSERT into @p values ('insert_cols_str'			, @insert_cols_str) 
	insert into @p values ('src_col_str'				, @src_col_str) 
	insert into @p values ('trg_db'				, @trg_db) 
	insert into @p values ('transfer_start_dt'		, @transfer_start_dt) 
	insert into @p values ('lookup_col_listing_str'		, @lookup_col_listing_str ) 
	insert into @p values ('sur_pkey1'			, @sur_pkey1) 
	insert into @p values ('col_mapping_trg_str'			, @col_mapping_trg_str) 
	insert into @p values ('col_mapping_src_str_delete_detectie'			, @col_mapping_src_str_delete_detectie) 
	insert into @p values ('col_mapping_src_str'			, @col_mapping_src_str) 
	insert into @p values ('compare_col_str_src'					, @compare_col_str_src	) 
	insert into @p values ('compare_col_str_trg'					, @compare_col_str_trg	) 
	
	insert into @p values ('trg_join_str'	, @trg_join_str ) 
	insert into @p values ('nat_prim_keys_str'	, @nat_prim_keys_str ) 
	insert into @p values ('nat_prim_key1'		, @nat_prim_key1 ) 
	insert into @p values ('nat_prim_key_match'	, @nat_prim_key_match ) 
	insert into @p values ('src_col_value_str'		, @src_col_value_str ) 
	insert into @p values ('trg_col_listing_str'		, @trg_col_listing_str ) 
	INSERT into @p values ('top'				, '')  -- you can fill in e.g. top 100 here
	INSERT into @p values ('filter_delete_detection'	, isnull('AND /* filter_delete_detection */'+ @filter_delete_detection,'') )  
	EXEC util.apply_params @lookup_sql output, @p
	insert into @p values ('lookup_sql'			, @lookup_sql) 
	EXEC util.apply_params @sql2 output, @p
	EXEC util.apply_params @sql_delete_detection output, @p
	set @sql+= @sql2
	exec @result = dbo.exec_sql @transfer_id=@transfer_id, @sql=@sql,  @async=@async
	if @result <> 0 
		goto footer
	exec @result = dbo.exec_sql @transfer_id, @sql_delete_detection
	if @result <> 0 
		goto footer
	select @status = status_name
	from static.status s
	inner join dbo.[transfer] t on s.status_id = t.status_id
	where t.transfer_id=@transfer_id
	if @status = 'error'
		goto footer
	-- END standard BETL footer code... 
	if @template_id IN ( 8)  -- Datavault Hub Sat (CDC and delete detection)
		exec @result = [dbo].[push]
			@full_obj_name=@full_obj_name
			, @batch_id=@batch_id
			, @template_id = 9 -- only sat
			, @scope =@scope
			, @async= @async
--			, @transfer_id=@transfer_id
	if @template_id IN ( 10)  -- Datavault Link Sat (CDC and delete detection)
		exec @result = [dbo].[push]
			@full_obj_name=@full_obj_name
			, @batch_id=@batch_id
			, @template_id = 11 -- only sat
			, @scope =@scope
--			, @transfer_id=@transfer_id
			, @async= @async

	if @template_id IN ( 4)  -- Truncate insert -> create stgh view
		exec @result = [dbo].[push]
			@full_obj_name=@trg_obj_name
			, @batch_id=@batch_id
			, @template_id = 5 -- only sat
			, @scope = @scope -- set current schema as scope
			, @async= @async
--			, @transfer_id=@transfer_id
		-- standard BETL footer code... 
   footer:

	end try 
	begin catch
		set @msg  =isnull(error_procedure()+ ', ','')+ ERROR_MESSAGE() 
		set @sev = ERROR_SEVERITY()
		set @number = ERROR_NUMBER() 
		exec dbo.log_error @transfer_id=@transfer_id, @msg=@msg,  @severity=@sev, @number=@number
		set @result = -3
		set @status='error'
	end catch 
	
   if @result is null
		set @result =-1
	if @result<>0 and @result<> -3
	begin
		set @status='error'
		exec dbo.log @transfer_id, 'error' , '? received error code ?', @proc_name, @result
	end
   exec dbo.end_transfer @transfer_id  ,@status
   if @is_running_in_batch=0 or @status in ('error')-- when push is not running part of a running batch-> close the batch that was created for this push ... 
	   exec dbo.end_batch @batch_id, @status
   
   exec dbo.log @transfer_id, 'footer', '?(?) ?(?) transfer_id ?', @proc_name, @status , @full_obj_name, @scope, @transfer_id
   
   -- make sure that caller ( e.g. ssis) also receives error 
   if @result <> 0 
   begin 
		set @msg  =isnull(error_procedure()+ ' ','')+ ' ended with error status.'
		RAISERROR(@msg , 15 , 0)  WITH NOWAIT
	end
		
   return @result 
END