﻿	  
/*------------------------------------------------------------------------------------------------
-- BETL, meta data driven ETL generation, licensed under GNU GPL https://github.com/basvdberg/BETL 
--------------------------------------------------------------------------------------------------
-- 2017-01-01 BvdB Create ddl for view  
declare @cols dbo.ColumnTable,
	@obj_id as int ,
	@src_obj as varchar(255) = 'AdventureWorks2014.rdv.imp_f_subs_cd_subscription'
exec dbo.get_obj_id @src_obj, @obj_id output
insert into @cols 
select * from dbo.get_cols(@obj_id)
exec create_view 'AdventureWorks2014.rdv.stgh_f_subs_cd_subscription', null, @cols, @src_obj 
*/ 
CREATE PROCEDURE [dbo].[create_view]
    @full_trg_obj_name AS VARCHAR(255) 
    , @scope AS VARCHAR(255) 
	, @cols AS dbo.ColumnTable READONLY
    , @full_src_obj_name AS VARCHAR(255) 
	, @transfer_id AS INT = -1
AS
BEGIN
	-- standard BETL header code... 
	set nocount on 
	declare  
		@proc_name as varchar(255) = object_name(@@PROCID)
		, @betl varchar(100) = db_name() 
	exec dbo.log @transfer_id, 'header', '? ?(?), scope ? ?', @proc_name , @full_trg_obj_name,  @full_src_obj_name, @scope, @transfer_id 
	-- END standard BETL header code... 
	declare @sql as varchar(max) 
		, @col_str as varchar(8000) =''
		, @nl as varchar(2) = char(13)+char(10)
		, @trg_db as varchar(255) 
		, @trg_obj_name as varchar(255) 
		, @src_obj_name as varchar(255) 
		, @trg_schema as varchar(255) 
		, @src_schema as varchar(255) 
		, @trg_schema_id as int
		, @src_schema_id as int
		, @this_db as varchar(255) = db_name()
		, @prim_key as varchar(1000) =''
		, @prim_key_sql as varchar(8000)=''
		, @p ParamTable
		, @unique_index as varchar(1000)=''
		, @index_sql as varchar(4000) 
		, @refresh_sql as varchar(4000) 
		, @recreate_tables as BIT
        , @obj_id AS INT 
	select @trg_schema_id=dbo.schema_id(@full_trg_obj_name, @scope) 
	select @src_schema_id=dbo.schema_id(@full_src_obj_name, @scope) 
	exec dbo.log @transfer_id, 'VAR', '@trg_schema_id ? ',@trg_schema_id
	exec dbo.log @transfer_id, 'VAR', '@src_schema_id ? ',@src_schema_id
	if @trg_schema_id < 0 
	begin
		exec dbo.log @transfer_id, 'ERROR', 'schema name is ambiguous. Please specify database name as well. ? ',@full_trg_obj_name
		goto footer
	end 
	if @trg_schema_id is null 
	begin
		exec dbo.log @transfer_id, 'ERROR', 'Cannot find target schema in betl meta data. ? ',@full_trg_obj_name
		goto footer
	end
	select 
		@trg_db = db 
		, @trg_schema = [schema]
		, @trg_obj_name =  util.obj_name(@full_trg_obj_name) 
	from dbo.obj_ext 
	where obj_id = @trg_schema_id
	select 
		@src_schema = [schema]
		, @src_obj_name =  util.obj_name(@full_src_obj_name) 
	from dbo.obj_ext 
	where obj_id = @src_schema_id
	exec dbo.log @transfer_id, 'VAR', '@trg_db ? ',@trg_db
	exec dbo.log @transfer_id, 'VAR', '@trg_obj_name  ? ',@trg_obj_name 
	
	select @col_str+= case when @col_str='' then '' else ',' end + 

			+ case 
				when data_type in ('money', 'smallmoney')  then ' convert(decimal('+ convert(varchar(10), numeric_precision) +  
																			   isnull ( ',' + convert(varchar(10), numeric_scale), '') + '),' 
																			    +'['+ lower(column_name) + '] ) as '+ '['+ lower(column_name) + ']'
				when data_type in ('nvarchar')  then ' convert(varchar'+ isnull('('+ case when max_len<0 then 'MAX' else convert(varchar(10), max_len ) end + ')', '')+',' 
																			    +'['+ lower(column_name) + '] ) as '+ '['+ lower(column_name) + ']'
				else '['+ lower(column_name) + '] '
			  end+ '
'
	from @cols 
	set @sql ='USE <trg_db>'

	set @sql ='
-------------------------------------------------
-- Start (re)create view DDL <full_trg_obj_name>
-------------------------------------------------	
--USE <trg_db>;
if object_id(''<trg_schema>.<trg_obj_name>'') is not null 
	drop view <trg_schema>.<trg_obj_name>
;
--GO
exec("
-- exec betl.dbo.push ""<trg_schema>.<trg_obj_name>""
create view <trg_schema>.<trg_obj_name> as
	SELECT 
	<col_str>
	FROM <src_schema>.<src_obj_name>
") 
--USE <this_db> 
-------------------------------------------------
-- End create view ddl <full_trg_obj_name>
-------------------------------------------------	
'
SET @refresh_sql = '
	exec <betl>.dbo.refresh "<trg_obj_name>" -- make sure that betl meta data is up to date
'
	insert into @p values ('betl'					, @betl) 
	INSERT INTO @p VALUES ('trg_obj_name'			, @trg_obj_name) 
	INSERT INTO @p VALUES ('full_trg_obj_name'		, @full_trg_obj_name) 
	INSERT INTO @p VALUES ('src_obj_name'			, @src_obj_name) 
	INSERT INTO @p VALUES ('full_src_obj_name'		, @full_src_obj_name) 
	INSERT INTO @p VALUES ('trg_db'						, @trg_db) 
	INSERT INTO @p VALUES ('trg_schema'					, @trg_schema) 
	INSERT INTO @p VALUES ('src_schema'					, @src_schema) 
	INSERT INTO @p VALUES ('col_str'				, @col_str) 
	INSERT INTO @p VALUES ('this_db'				, @this_db) 
	INSERT INTO @p VALUES ('refresh_sql'			, @refresh_sql) 
	EXEC util.apply_params @sql OUTPUT, @p
	EXEC util.apply_params @sql OUTPUT, @p -- twice because of nesting
	
	exec dbo.exec_sql @transfer_id, @sql, @trg_db
	EXEC dbo.get_obj_id @trg_obj_name, @obj_id OUTPUT -- this will also do a refresh
	exec dbo.log @transfer_id, 'VAR', 'obj_id ? = ?', @trg_obj_name, @obj_id
	-- standard BETL footer code... 
    footer:
	exec dbo.log @transfer_id, 'footer', 'DONE ? ? ? ?', @proc_name , @trg_obj_name, @transfer_id
	-- END standard BETL footer code... 
END