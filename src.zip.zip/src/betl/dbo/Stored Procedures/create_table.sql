﻿	  
/*------------------------------------------------------------------------------------------------
-- BETL, meta data driven ETL generation, licensed under GNU GPL https://github.com/basvdberg/BETL 
--------------------------------------------------------------------------------------------------
-- 2017-01-01 BvdB create table ddl 
--don't create primary keys for performance reasons (lock last page clustered index )
--unique indexes:
--hubs:
--on all nat_pkeys 
--hub sats:
--on all nat_pkeys 
--note that etl_load_dt is included
--links
--on all sur_fkeys + nat_pkeys
--link sats
--on all sur_fkeys + nat_pkeys
--note that etl_load_dt is included
--drop PROCEDURE [dbo].[create_table]
*/
CREATE PROCEDURE [dbo].[create_table]
    @full_obj_name AS VARCHAR(255) 
    , @scope AS VARCHAR(255) 
	, @cols AS dbo.ColumnTable READONLY
	, @transfer_id AS INT = -1
	, @create_pkey AS BIT =1 
AS
BEGIN
	-- standard BETL header code... 
	set nocount on 
	declare  @proc_name as varchar(255) =  object_name(@@PROCID)
		, @betl varchar(100) =db_name() 

	exec dbo.log @transfer_id, 'header', '? ?, scope ? ?', @proc_name , @full_obj_name,  @scope, @transfer_id 
	-- END standard BETL header code... 
	declare @sql as varchar(max) 
			, @col_str as varchar(max) =''
			, @nl as varchar(2) = char(13)+char(10)
			, @db as varchar(255) 
			, @obj_name as varchar(255) 
			, @schema as varchar(255) 
			, @schema_id as int
			, @this_db as varchar(255) = db_name()
			, @prim_key as varchar(1000) =''
			, @prim_key_sql as varchar(max)=''
			, @p ParamTable
			, @unique_index as varchar(1000)=''
			, @index_sql as varchar(max) 
			, @refresh_sql as varchar(max)
			, @recreate_tables as BIT
            , @obj_id AS INT 
	select @schema_id=dbo.schema_id(@full_obj_name, @scope)  -- 
	select 
		@db = db 
		, @schema = [schema]
		, @obj_name =  util.obj_name(@full_obj_name) 
	from dbo.obj_ext 
	where obj_id = @schema_id
	select @col_str+= case when @col_str='' then '' else ',' end + 
	'['+ column_name + '] ['+ case when data_type in ('money', 'smallmoney')  then 'decimal' else data_type end + ']'
		+ case when data_type in ( 'varchar', 'nvarchar', 'char', 'nchar', 'varbinary') then  isnull('('+ case when max_len<0 then 'MAX' else convert(varchar(10), max_len ) end + ')', '')
			   when numeric_precision is not null then '('+ convert(varchar(10), numeric_precision) +  
														isnull ( ',' + convert(varchar(10), numeric_scale), '') + ')' 
				else ''
		  end
	   + case when [identity] = 1 then ' IDENTITY(1,1) ' else '' end + 
		case when is_nullable=0 or ( column_type_id in (100,200) )   then ' NOT NULL' else ' NULL' end 
--		case when is_nullable=0   then ' NOT NULL' else ' NULL' end 
		+ case when column_value is null then '' else ' DEFAULT ('+ column_value + ')' end	
		+ ' -- '+ dbo.column_type_name(column_type_id) +@nl
	from @cols 
	select @prim_key+= case when @prim_key='' then '' else ',' end + 
	'['+ column_name + ']' + @nl
	from @cols 
	where column_type_id = 200 -- sur_pkey
	order by ordinal_position asc
	select @unique_index+= case when @unique_index='' then '' else ',' end + '['+ column_name + ']' + @nl
	from @cols 
	where part_of_unique_index = 1 
	order by ordinal_position asc
	
	-- exec dbo.log @transfer_id, 'VAR', '@unique_index ?', @unique_index
	if @prim_key='' 
		set @prim_key = @unique_index 
	if @unique_index is not null and @unique_index <> '' 
		set @index_sql = '
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = N"IX_<obj_name_striped>_<schema_id>")
ALTER TABLE <schema>.<obj_name> ADD CONSTRAINT
	IX_<obj_name_striped>_<schema_id> UNIQUE NONCLUSTERED 
	(
	<unique_index>
	) 
'
--skip this for performance reasons... 
	if @prim_key is not null and @prim_key<> '' and @create_pkey=1
		set @prim_key_sql = '
IF  NOT EXISTS (SELECT * FROM sys.indexes WHERE name = N"PK_<obj_name_striped>_<schema_id>")
ALTER TABLE <schema>.<obj_name> ADD CONSTRAINT
	PK_<obj_name_striped>_<schema_id> PRIMARY KEY CLUSTERED 
	(
	<prim_key>
	) 
'
/*
-- create FK to etl_data_source
IF  NOT EXISTS (SELECT * FROM sys.indexes WHERE name = N"FK_<obj_name_striped>_<schema_id>_etl_data_source")
begin
	ALTER TABLE <schema>.<obj_name> WITH CHECK ADD  CONSTRAINT 
		FK_<obj_name_striped>_<schema_id>_etl_data_source FOREIGN KEY([etl_data_source])
	REFERENCES [dbo].[etl_data_source] ([etl_data_source])
	ALTER TABLE <schema>.<obj_name> CHECK CONSTRAINT FK_<obj_name_striped>_<schema_id>_etl_data_source
end
*/
	set @sql ='
-------------------------------------------------
-- Start create table DDL <full_obj_name>
-------------------------------------------------	
USE <db> 
'
	select @recreate_tables = dbo.get_prop_obj_id('recreate_tables', @schema_id ) 
	if @recreate_tables =1 
	begin
		exec dbo.log @transfer_id, 'step', '@recreate_tables =1->drop table ?', @full_obj_name
		SET @sql += '
-- recreate table =1 
if object_id(''<schema>.<obj_name>'') is not null 
	drop table <schema>.<obj_name>
;
'

	END

	SET @sql += '
if object_id(''<schema>.<obj_name>'') is null 
begin 
	CREATE Table <schema>.<obj_name> (
		<col_str>
	) ON [PRIMARY]
	<prim_key_sql>
	<index_sql>
	<refresh_sql>
end
	
USE <this_db> 
-------------------------------------------------
-- End create table DDL <full_obj_name>
-------------------------------------------------	
'
SET @refresh_sql = '
	exec <betl>.dbo.refresh ''[<db>].[<schema>].<obj_name>'' -- make sure that betl meta data is up to date
'
-- not needed because we do a get_obj_id after this, which will also issue a refresh
--	
	insert into @p values ('betl'					, @betl) 
	INSERT INTO @p VALUES ('full_obj_name'		, @full_obj_name) 
	INSERT INTO @p VALUES ('db'						, @db) 
	INSERT INTO @p VALUES ('schema'					, @schema) 
	INSERT INTO @p VALUES ('col_str'				, @col_str) 
	INSERT INTO @p VALUES ('prim_key_sql'			, ISNULL(@prim_key_sql,'') ) 
	INSERT INTO @p VALUES ('index_sql'				, ISNULL(@index_sql,'') ) 
	INSERT INTO @p VALUES ('this_db'				, @this_db) 
	INSERT INTO @p VALUES ('obj_name'				, @obj_name) 
	INSERT INTO @p VALUES ('obj_name_striped'		, REPLACE(REPLACE(@obj_name, '[', ''), ']', '') )
	INSERT INTO @p VALUES ('schema_id'				, @schema_id) 
	INSERT INTO @p VALUES ('prim_key'				, @prim_key ) 
	INSERT INTO @p VALUES ('unique_index'		    , @unique_index ) 
	INSERT INTO @p VALUES ('refresh_sql'			, @refresh_sql) 
	EXEC util.apply_params @sql OUTPUT, @p
	EXEC util.apply_params @sql OUTPUT, @p -- twice because of nesting
	exec dbo.exec_sql @transfer_id, @sql
	EXEC dbo.get_obj_id @full_obj_name, @obj_id OUTPUT -- this will also do a refresh
	exec dbo.log @transfer_id, 'VAR', 'obj_id ? = ?', @full_obj_name, @obj_id
	IF @obj_id IS NOT NULL 
		-- finally set column_type meta data 
	   UPDATE c 
	   SET c.column_type_id = cols.column_type_id
	   FROM @cols cols
	   INNER JOIN dbo.Col c ON cols.column_name = c.column_name 
	   WHERE cols.column_type_id IS NOT NULL 
		AND c.[obj_id] = @obj_id
--	SET @refresh_sql = '		exec betl.dbo.refresh ''<schema>.<obj_name>''	'
	-- standard BETL footer code... 
    footer:
	exec dbo.log @transfer_id, 'footer', 'DONE ? ? ? ?', @proc_name , @full_obj_name, @transfer_id
	-- END standard BETL footer code... 
END