﻿	  
/*------------------------------------------------------------------------------------------------
-- BETL, meta data driven ETL generation, licensed under GNU GPL https://github.com/basvdberg/BETL 
--------------------------------------------------------------------------------------------------
-- 2017-01-01 BvdB decreate nesting level (e.g. for logging). 
-- DEPRECATED. Use @@NESTLEVEL instead

log_level
10 ERROR
20 INFO : show progress in current proc
30 DEBUG: : show progress in current proc and invoked procs. 
*/
CREATE PROCEDURE [dbo].[dec_nesting] 
as 
begin 
	declare @nesting as smallint 
	exec dbo.getp 'nesting', @nesting output
	set @nesting = isnull(@nesting-1, 0) 
	exec dbo.setp  'nesting', @nesting
end