﻿CREATE TABLE [static].[Status] (
    [status_id]   INT           NOT NULL,
    [status_name] VARCHAR (50)  NULL,
    [description] VARCHAR (255) NULL,
    CONSTRAINT [PK_Status] PRIMARY KEY CLUSTERED ([status_id] ASC)
);

