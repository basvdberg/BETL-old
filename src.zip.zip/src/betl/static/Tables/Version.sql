﻿CREATE TABLE [static].[Version] (
    [major_version] INT      NOT NULL,
    [minor_version] INT      NOT NULL,
    [build]         INT      NOT NULL,
    [build_dt]      DATETIME NULL,
    CONSTRAINT [PK_Version] PRIMARY KEY CLUSTERED ([major_version] ASC, [minor_version] ASC, [build] ASC)
);

