﻿CREATE TABLE [static].[Dep_type] (
    [dep_type_id]          SMALLINT      NOT NULL,
    [dep_type]             VARCHAR (100) NULL,
    [dep_type_description] VARCHAR (255) NULL,
    [record_dt]            DATETIME      CONSTRAINT [DF_Dep_type_record_dt] DEFAULT (getdate()) NULL,
    [record_user]          VARCHAR (255) CONSTRAINT [DF_Dep_type_record_user] DEFAULT (suser_sname()) NULL,
    CONSTRAINT [PK_Dep_type] PRIMARY KEY CLUSTERED ([dep_type_id] ASC)
);

