﻿CREATE TABLE [static].[Log_level] (
    [log_level_id]          SMALLINT      NOT NULL,
    [log_level]             VARCHAR (50)  NULL,
    [log_level_description] VARCHAR (255) NULL,
    CONSTRAINT [PK_Log_level_1] PRIMARY KEY CLUSTERED ([log_level_id] ASC)
);

