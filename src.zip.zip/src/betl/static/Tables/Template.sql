﻿CREATE TABLE [static].[Template] (
    [template_id]          SMALLINT       NOT NULL,
    [is_etl_template]      BIT            NULL,
    [template_name]        VARCHAR (100)  NULL,
    [template_description] VARCHAR (255)  NULL,
    [template_sql]         NVARCHAR (MAX) NULL,
    [record_dt]            DATETIME       CONSTRAINT [DF__Template__record__693CA210] DEFAULT (getdate()) NULL,
    [record_name]          VARCHAR (255)  CONSTRAINT [DF__Template__record__6A30C649] DEFAULT (suser_sname()) NULL,
    CONSTRAINT [PK_Template] PRIMARY KEY CLUSTERED ([template_id] ASC)
);


GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Template_name]
    ON [static].[Template]([template_name] ASC);

