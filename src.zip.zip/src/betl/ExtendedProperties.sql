﻿EXECUTE sp_addextendedproperty @name = N'Description', @value = N'dbo data is specific for each customer implementation', @level0type = N'SCHEMA', @level0name = N'dbo';

